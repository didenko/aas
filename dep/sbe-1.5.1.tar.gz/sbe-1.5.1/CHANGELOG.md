# Changelog

## 1.0.2-RC2-SNAPSHOT ()

*

## 1.0.1-RC2 (2014-06-16)

* Java codecs will not emit imports for enums (#166)
* C++ codecs now disallow copy construction and have generic constructor (#164)
* javac tasks all use source and target of 1.7 (#161)
* Utility method to copy from DirectBuffer to DirectBuffer (#147, #163)
* Codec clean ups for formatting

## 1.0.1-RC2-SNAPSHOT

* 2014-05-11: C++ codecs now include optional bounds checking (#130)

## 1.0-RC2 (2014-05-03)

Initial public release (based on FIX/SBE RC2)
Release to maven central
